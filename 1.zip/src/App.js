import { BrowserRouter } from 'react-router-dom';
import './App.css';
import AppRouter from './Routes/Routes';

function App() {
  return (
    <BrowserRouter>
      <div className='min-h-screen flex flex-col content-between'>
        <div className='flex-1'>
          <AppRouter />
        </div>
      </div>
    </BrowserRouter>
  );
}

export default App;
